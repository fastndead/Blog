CREATE procedure GetPostById @id int
as
  select tp.c_id as id, tp.c_title as title, tp.c_text as text, tp.fk_author as userId from t_post tp where tp.c_id = @id;
go

