CREATE VIEW post_topic_view
AS
SELECT post.c_title AS 'title',
		ta.c_name AS 'author',
		post.c_text AS 'text',
		post.c_create_date AS 'create_date',
        tt.c_name as 'topic'
FROM t_post post
INNER JOIN t_author ta on post.fk_author = ta.c_id
INNER JOIN toc_post_topic tpt on ta.c_id = tpt.fk_post
INNER JOIN t_topic tt on tpt.fk_topic = tt.c_id
    where len(tt.c_name)  < 20
WITH CHECK OPTION;
go

