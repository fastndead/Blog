CREATE procedure logIn @userName varchar(300), @password varchar(300)
as
  select c_id as c_id from t_author
  where c_password = @password and
        c_name = @userName;
go

