create procedure Unsubscribe @authorId int, @subscriberId int
as
delete from t_follower where fk_author = @authorId and fk_follower = @subscriberId
go

