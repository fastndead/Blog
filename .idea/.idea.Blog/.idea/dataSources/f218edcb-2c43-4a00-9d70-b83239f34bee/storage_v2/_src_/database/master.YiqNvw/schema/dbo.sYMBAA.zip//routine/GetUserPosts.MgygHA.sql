CREATE PROCEDURE GetUserPosts @id int
AS
  SELECT tp.c_id as id, 
         tp.c_text as text, 
         tp.c_title as title, 
         tp.c_rating as rating,
         tp.c_create_date as createDate
  FROM t_post tp where tp.fk_author = @id
go

