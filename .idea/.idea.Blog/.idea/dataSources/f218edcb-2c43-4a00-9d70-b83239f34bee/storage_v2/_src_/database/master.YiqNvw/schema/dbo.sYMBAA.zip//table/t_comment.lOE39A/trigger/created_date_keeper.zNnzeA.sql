CREATE TRIGGER created_date_keeper
ON t_comment
instead of update
AS
update t_comment set t_comment.fk_author = inserted.fk_author,
                     t_comment.c_text = inserted.c_text,
                     t_comment.c_edit_date = default
from inserted
    where t_comment.c_id = inserted.c_id
go

