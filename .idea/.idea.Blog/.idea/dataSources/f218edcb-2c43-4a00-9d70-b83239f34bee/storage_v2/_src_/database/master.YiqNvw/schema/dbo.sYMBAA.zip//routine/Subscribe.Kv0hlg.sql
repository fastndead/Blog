create procedure Subscribe @authorId int, @subscriberId int
as
    insert into t_follower(fk_author, fk_follower) values (@authorId, @subscriberId)
go

