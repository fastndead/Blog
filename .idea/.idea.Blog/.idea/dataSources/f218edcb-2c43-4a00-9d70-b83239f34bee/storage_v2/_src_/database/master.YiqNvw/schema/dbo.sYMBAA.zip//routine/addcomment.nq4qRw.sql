create procedure AddComment @id int, @text varchar(300), @authorId int
as
  insert into t_comment(fk_post, c_text, fk_author) 
  values (@id, @text, @authorId);
go

