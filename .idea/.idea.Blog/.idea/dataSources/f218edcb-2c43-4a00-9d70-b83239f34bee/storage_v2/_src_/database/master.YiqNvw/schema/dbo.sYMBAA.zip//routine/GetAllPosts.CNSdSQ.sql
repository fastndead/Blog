CREATE procedure GetAllPosts
as
  select  posts.fk_author as authorId, posts.c_text as text, posts.c_id as id, posts.c_title as title from t_post as posts;
go

