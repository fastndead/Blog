CREATE VIEW post_view
AS
SELECT post.c_title AS 'title',
		ta.c_name AS 'author',
		post.c_text AS 'text',
		post.c_create_date AS 'create_date'
FROM t_post post
INNER JOIN t_author ta on post.fk_author = ta.c_id;
go

