create procedure GetSubscriptions @id int
as
    select c_name as name, c_id as id from t_author left join t_follower tf on t_author.c_id = tf.fk_follower
where tf.fk_author = @id
go

