CREATE procedure CheckSubscription @authorId int, @subscriberId int
as
SELECT *
FROM t_follower t
WHERE t.fk_author = @authorId and t.fk_follower = @subscriberId;
go

