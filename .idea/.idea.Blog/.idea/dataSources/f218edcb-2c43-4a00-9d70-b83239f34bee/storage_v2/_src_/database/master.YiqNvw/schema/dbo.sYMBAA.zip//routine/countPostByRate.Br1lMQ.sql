CREATE PROCEDURE countPostByRate
@rate int
AS
DECLARE @id_cursor INT, @cnt INT = 0
DECLARE Mycursor CURSOR FOR
    SELECT c_id
    FROM t_post
    WHERE c_rating >= @rate
    OPEN Mycursor
    FETCH NEXT FROM Mycursor
        INTO @id_cursor
    WHILE @@FETCH_STATUS = 0
    BEGIN
        set @cnt = @cnt + 1
        FETCH NEXT FROM Mycursor
            INTO @id_cursor
    END
    CLOSE Mycursor
    DEALLOCATE Mycursor
    RETURN @cnt
go

