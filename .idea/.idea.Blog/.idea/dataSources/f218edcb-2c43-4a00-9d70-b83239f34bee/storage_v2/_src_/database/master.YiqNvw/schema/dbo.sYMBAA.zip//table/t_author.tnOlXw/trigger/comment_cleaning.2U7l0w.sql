CREATE TRIGGER comment_cleaning on t_author
    after delete as
    delete t_comment 
    where fk_author = (select c_id from deleted)
go

