create procedure GetRoleById @id int
  as 
  select c_role from t_login where c_id = @id;
go

