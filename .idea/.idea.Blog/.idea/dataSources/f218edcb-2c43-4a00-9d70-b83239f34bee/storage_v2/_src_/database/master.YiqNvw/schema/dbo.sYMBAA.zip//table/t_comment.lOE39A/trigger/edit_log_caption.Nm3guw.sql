CREATE TRIGGER edit_log_caption
ON t_comment
after update
AS
update t_comment set t_comment.c_text = deleted.c_text +
                                        '. UPD: ' +
                                        inserted.c_text
    from deleted join inserted on deleted.c_id = inserted.c_id
    where t_comment.c_id = inserted.c_id
go

