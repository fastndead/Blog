CREATE VIEW post_title_view
WITH SCHEMABINDING
AS
select dbo.t_post.c_id as 'id', dbo.t_post.c_title, ta.c_name
from dbo.t_post INNER JOIN
    dbo.t_author ta on t_post.fk_author = ta.c_id;
go

