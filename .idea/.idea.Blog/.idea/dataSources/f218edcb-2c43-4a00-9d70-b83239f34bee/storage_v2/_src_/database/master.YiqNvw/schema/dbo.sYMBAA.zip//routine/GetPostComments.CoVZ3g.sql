CREATE procedure GetPostComments @id int
  as 
  select tc.c_text as text,
         tc.fk_author as authorId, 
         tc.c_create_date as createDate 
  from t_comment tc 
  where tc.fk_post = @id;
go

